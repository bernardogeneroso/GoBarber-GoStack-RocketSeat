export default {
  jwt: {
    secret: 'e959ace279e564bf838de1913cd1de69',
    expiresIn: '1d'
  }
}
