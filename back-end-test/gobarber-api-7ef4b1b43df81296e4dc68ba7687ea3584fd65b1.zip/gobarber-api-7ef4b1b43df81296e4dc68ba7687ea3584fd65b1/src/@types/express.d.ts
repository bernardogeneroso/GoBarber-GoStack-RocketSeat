declare namespace Express {
  export interface IRequest {
    user: {
      id: string
    }
  }
}
