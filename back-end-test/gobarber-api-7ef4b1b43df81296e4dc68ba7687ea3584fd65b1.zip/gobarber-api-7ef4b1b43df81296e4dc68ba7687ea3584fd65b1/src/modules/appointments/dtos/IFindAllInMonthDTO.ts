interface IFindAllInMonthDTO {
  provider_id: string
  month: number
  year: number
}

export default IFindAllInMonthDTO
