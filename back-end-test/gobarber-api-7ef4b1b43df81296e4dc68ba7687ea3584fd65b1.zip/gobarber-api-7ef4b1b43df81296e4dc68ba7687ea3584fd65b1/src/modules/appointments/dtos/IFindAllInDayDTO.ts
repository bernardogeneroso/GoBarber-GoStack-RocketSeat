interface IFindAllInDayDTO {
  provider_id: string
  day: number
  month: number
  year: number
}

export default IFindAllInDayDTO
