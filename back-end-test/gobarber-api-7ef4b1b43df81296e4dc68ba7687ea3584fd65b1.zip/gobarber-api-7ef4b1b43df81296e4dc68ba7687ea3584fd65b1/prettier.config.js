module.exports = {
  singleQuote: true,
  trailingComma: 'none',
  arrowParens: 'avoid',
  semi: false
};
